<template>
    <layout-div>
          <div class="container">
              <h2 class="text-center mt-5 mb-3">Project Manager</h2>
              <div class="card">
                  <div class="card-header">
                      <router-link to="/create"
                          class="btn btn-outline-primary"
                          >Create New Project
                      </router-link>
                  </div>
                  <div class="card-body">
               
                      <table class="table table-bordered">
                          <thead>
                              <tr>
                                  <th>idroutePk</th>
		<th>route</th>
		<th>etat</th>
		<th>numero</th>
		
                                  <th width="240px">Action</th>
                              </tr>
                          </thead>
                          <tbody>
                               
                              <tr v-for="project in projects" :key="project.id">
                                <td>{{project.idroutePk}}</td>
		<td>{{project.route}}</td>
		<td>{{project.etat}}</td>
		<td>{{project.numero}}</td>
		
                                  <td>
                                  <router-link :to="`/RoutePkEdit/${project.idroutepk}`" class="btn btn-outline-info mx-1">Edit</router-link>
		<router-link :to="`/RoutePkShow/${project.idroutepk}`" class="btn btn-outline-info mx-1">Show</router-link>
		<router-link :to="`/RoutePkCreate/${project.idroutepk}`" class="btn btn-outline-info mx-1">Create</router-link>
		
                                      <button 
                                          @click="handleDelete(project.id)"
                                          className="btn btn-outline-danger mx-1">
                                          Delete
                                      </button>
                                  </td>
                              </tr>
                                   
                          </tbody>
                      </table>
                  </div>
              </div>
          </div>
      </layout-div>
  </template>
   <script>

import  axios from 'axios';

import   LayoutDiv from '../LayoutDiv.vue';

import   Swal from 'sweetalert2';

   
  export default {
    name: 'RoutePkList',
    components: {
      LayoutDiv,
    },
    data() {
      return {
        projects:[]
      };
    },
    created() {
      this.fetchProjectList();
    },
    methods: {
      fetchProjectList() {
        axios.get('Lalana/tocrudroutepk.do')
          .then(response => {
              this.projects = response.data.o;
              return response
          })
          .catch(error => {
            return error
          });
      },
      handleDelete(id){
                  Swal.fire({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
              if (result.isConfirmed) {
                  axios.delete(`Lalana/tocrudroutepk.do/${id}`)
                  .then( response => {
                      Swal.fire({
                          icon: 'success',
                          title: 'Project deleted successfully!',
                          showConfirmButton: false,
                          timer: 1500
                      })
                      this.fetchProjectList();
                      return response
                  })
                  .catch(error => {
                      Swal.fire({
                           icon: 'error',
                          title: 'An Error Occured!',
                          showConfirmButton: false,
                          timer: 1500
                      })
                      return error
                  });
              }
            })
      }
    },
  };
  </script>