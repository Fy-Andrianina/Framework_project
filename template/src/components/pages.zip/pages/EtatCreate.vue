<template>
    <layout-div>
         <h2 class="text-center mt-5 mb-3">Edit Project</h2>
         <div class="card">
             <div class="card-header">
                 <router-link 
                     class="btn btn-outline-info float-right"
                     to="/">View All Projects
                 </router-link>
             </div>
             <div class="card-body">
                <form>
                    //#dataInput#
                    <div class="form-group">
    <label htmlFor="idetat">idetat</label>
    <input 
        v-model="project.idetat"
        type="String"
        class="form-control"
        id="idetat"
        name="idetat"/>
</div>
		<div class="form-group">
    <label htmlFor="debut">debut</label>
    <input 
        v-model="project.debut"
        type="Double"
        class="form-control"
        id="debut"
        name="debut"/>
</div>
		<div class="form-group">
    <label htmlFor="description">description</label>
    <input 
        v-model="project.description"
        type="String"
        class="form-control"
        id="description"
        name="description"/>
</div>
		
                     <button 
                         @click="handleSave()"
                         :disabled="isSaving"
                         type="button"
                         class="btn btn-outline-primary mt-3">
                         Save Project
                     </button>
                </form>
             </div>
         </div>
    </layout-div>
 </template>
 <script>

import  axios from 'axios';

import   LayoutDiv from '../LayoutDiv.vue';

import   Swal from 'sweetalert2';

 export default {
   name: 'EtatCreate',
   components: {
     LayoutDiv,
   },
   data() {
     return {
       project: {
         idetat: '',
		debut: '',
		description: '',
		
       },
       isSaving:false,
     };
   },
   created() {
            // prends la valeur de l'id specifie dans l'url /api/:id
     const id = this.$route.params.id;
     
     axios.get(`Lalana/updateetat.do/${id}`)
     .then(response => {
         let projectInfo = response.data
         this.project.idetat = projectInfo.idetat
		this.project.debut = projectInfo.debut
		this.project.description = projectInfo.description
		
         return response
     })
     .catch(error => {
         Swal.fire({
             icon: 'error',
             title: 'An Error Occured!',
             showConfirmButton: false,
             timer: 1500
         })
         return error
     })
   },
   methods: {
     handleSave() {
               this.isSaving = true
         const id = this.$route.params.id;
         axios.patch(`Lalana/updateetat.do/${id}`, this.project)
           .then(response => {
             Swal.fire({
                 icon: 'success',
                 title: 'Project updated successfully!',
                 showConfirmButton: false,
                 timer: 1500
             })
             this.isSaving = false
            this.project.idetat = ""
		this.project.debut = ""
		this.project.description = ""
		
             return response
           })
           .catch(error => {
             this.isSaving = false
             Swal.fire({
                 icon: 'error',
                 title: 'An Error Occured!',
                 showConfirmButton: false,
                 timer: 1500
             })
             return error
           });
     },
   },
 };
 </script>