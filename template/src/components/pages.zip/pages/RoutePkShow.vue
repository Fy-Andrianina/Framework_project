<template>
    <layout-div>
         <h2 class="text-center mt-5 mb-3">Show Project</h2>
         <div class="card">
             <div class="card-header">
                 <router-link 
                     class="btn btn-outline-info float-right"
                     to="/">View All Projects
                 </router-link>
             </div>
             <div class="card-body">
                 <b className="text-muted">Name:</b>
                // #dataParagraph#
                <b className="text-muted">idroutePk:</b>
<p>{{project.idroutePk}}</p>
		<b className="text-muted">route:</b>
<p>{{project.route}}</p>
		<b className="text-muted">etat:</b>
<p>{{project.etat}}</p>
		<b className="text-muted">numero:</b>
<p>{{project.numero}}</p>
		
             </div>
         </div>
    </layout-div>
 </template>
  
<script>
 
import  axios from 'axios';

import   LayoutDiv from '../LayoutDiv.vue';

import   Swal from 'sweetalert2';

  
 export default {
   name: 'RoutePkShow',
   components: {
     LayoutDiv,
   },
   data() {
     return {
       project: {
        idroutePk: '',
		route: '',
		etat: '',
		numero: '',
		
       },
       isSaving:false,
     };
   },
   created() {
         // prends la valeur de l'id specifie dans l'url /api/:id
     const id = this.$route.params.id;
     
     axios.get(`Lalana/updateroutepk.do/${id}`)
     .then(response => {
         let projectInfo = response.data
         this.project.idroutePk = projectInfo.idroutePk
		this.project.route = projectInfo.route
		this.project.etat = projectInfo.etat
		this.project.numero = projectInfo.numero
		
         return response
     })
     .catch(error => {
         Swal.fire({
             icon: 'error',
             title: 'An Error Occured!',
             showConfirmButton: false,
             timer: 1500
         })
         return error
     })
   },
   methods: {
      
   },
 };
 </script>