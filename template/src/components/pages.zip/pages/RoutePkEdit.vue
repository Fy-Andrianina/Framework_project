<template>
    <layout-div>
         <h2 class="text-center mt-5 mb-3">Edit Project</h2>
         <div class="card">
             <div class="card-header">
                 <router-link 
                     class="btn btn-outline-info float-right"
                     to="/">View All Projects
                 </router-link>
             </div>
             <div class="card-body">
                 <form>
                   // #dataInput#
                   <div class="form-group">
    <label htmlFor="idroutePk">idroutePk</label>
    <input 
        v-model="project.idroutePk"
        type="String"
        class="form-control"
        id="idroutePk"
        name="idroutePk"/>
</div>
		<div class="form-group">
    <label htmlFor="route">route</label>
    <input 
        v-model="project.route"
        type="Route"
        class="form-control"
        id="route"
        name="route"/>
</div>
		<div class="form-group">
    <label htmlFor="etat">etat</label>
    <input 
        v-model="project.etat"
        type="Double"
        class="form-control"
        id="etat"
        name="etat"/>
</div>
		<div class="form-group">
    <label htmlFor="numero">numero</label>
    <input 
        v-model="project.numero"
        type="Double"
        class="form-control"
        id="numero"
        name="numero"/>
</div>
		
                     <button 
                         @click="handleSave()"
                         :disabled="isSaving"
                         type="button"
                         class="btn btn-outline-primary mt-3">
                         Save Project
                     </button>
                 </form>
             </div>
         </div>
    </layout-div>
 </template>
<script>

import  axios from 'axios';

import   LayoutDiv from '../LayoutDiv.vue';

import   Swal from 'sweetalert2';
 
 export default {
   name: 'RoutePkEdit',
   components: {
     LayoutDiv,
   },
   data() {
     return {
       project: {
         idroutePk: '',
		route: '',
		etat: '',
		numero: '',
		
       },
       isSaving:false,
     };
   },
   created() {
        // prends la valeur de l'id specifie dans l'url /api/:id
     const id = this.$route.params.id;
     
     axios.get(`Lalana/updateroutepk.do/${id}`)
     .then(response => {
         let projectInfo = response.data
         this.project.idroutePk = projectInfo.idroutePk
		this.project.route = projectInfo.route
		this.project.etat = projectInfo.etat
		this.project.numero = projectInfo.numero
		
         return response
     })
     .catch(error => {
         Swal.fire({
             icon: 'error',
             title: 'An Error Occured!',
             showConfirmButton: false,
             timer: 1500
         })
         return error
     })
   },
   methods: {
     handleSave() {
             this.isSaving = true
         const id = this.$route.params.id;
         axios.patch(`Lalana/updateroutepk.do/${id}`, this.project)
           .then(response => {
             Swal.fire({
                 icon: 'success',
                 title: 'Project updated successfully!',
                 showConfirmButton: false,
                 timer: 1500
             })
             this.isSaving = false
            this.project.idroutePk = ""
		this.project.route = ""
		this.project.etat = ""
		this.project.numero = ""
		
             return response
           })
           .catch(error => {
             this.isSaving = false
             Swal.fire({
                 icon: 'error',
                 title: 'An Error Occured!',
                 showConfirmButton: false,
                 timer: 1500
             })
             return error
           });
     },
   },
 };
 </script>
 