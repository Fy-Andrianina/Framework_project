<template>
    <layout-div>
         <h2 class="text-center mt-5 mb-3">Show Project</h2>
         <div class="card">
             <div class="card-header">
                 <router-link 
                     class="btn btn-outline-info float-right"
                     to="/">View All Projects
                 </router-link>
             </div>
             <div class="card-body">
                 <b className="text-muted">Name:</b>
                // #dataParagraph#
                <b className="text-muted">idetat:</b>
<p>{{project.idetat}}</p>
		<b className="text-muted">debut:</b>
<p>{{project.debut}}</p>
		<b className="text-muted">description:</b>
<p>{{project.description}}</p>
		
             </div>
         </div>
    </layout-div>
 </template>
  
<script>
 
import  axios from 'axios';

import   LayoutDiv from '../LayoutDiv.vue';

import   Swal from 'sweetalert2';

  
 export default {
   name: 'EtatShow',
   components: {
     LayoutDiv,
   },
   data() {
     return {
       project: {
        idetat: '',
		debut: '',
		description: '',
		
       },
       isSaving:false,
     };
   },
   created() {
         // prends la valeur de l'id specifie dans l'url /api/:id
     const id = this.$route.params.id;
     
     axios.get(`Lalana/updateetat.do/${id}`)
     .then(response => {
         let projectInfo = response.data
         this.project.idetat = projectInfo.idetat
		this.project.debut = projectInfo.debut
		this.project.description = projectInfo.description
		
         return response
     })
     .catch(error => {
         Swal.fire({
             icon: 'error',
             title: 'An Error Occured!',
             showConfirmButton: false,
             timer: 1500
         })
         return error
     })
   },
   methods: {
      
   },
 };
 </script>