<template>
    <layout-div>
         <h2 class="text-center mt-5 mb-3">Edit Project</h2>
         <div class="card">
             <div class="card-header">
                 <router-link 
                     class="btn btn-outline-info float-right"
                     to="/">View All Projects
                 </router-link>
             </div>
             <div class="card-body">
                 <form>
                   // #dataInput#
                   <div class="form-group">
    <label htmlFor="idprestation">idprestation</label>
    <input 
        v-model="project.idprestation"
        type="String"
        class="form-control"
        id="idprestation"
        name="idprestation"/>
</div>
		<div class="form-group">
    <label htmlFor="nom">nom</label>
    <input 
        v-model="project.nom"
        type="String"
        class="form-control"
        id="nom"
        name="nom"/>
</div>
		<div class="form-group">
    <label htmlFor="etat">etat</label>
    <input 
        v-model="project.etat"
        type="Etat"
        class="form-control"
        id="etat"
        name="etat"/>
</div>
		<div class="form-group">
    <label htmlFor="prix">prix</label>
    <input 
        v-model="project.prix"
        type="Double"
        class="form-control"
        id="prix"
        name="prix"/>
</div>
		
                     <button 
                         @click="handleSave()"
                         :disabled="isSaving"
                         type="button"
                         class="btn btn-outline-primary mt-3">
                         Save Project
                     </button>
                 </form>
             </div>
         </div>
    </layout-div>
 </template>
<script>

import  axios from 'axios';

import   LayoutDiv from '../LayoutDiv.vue';

import   Swal from 'sweetalert2';
 
 export default {
   name: 'PrestationEdit',
   components: {
     LayoutDiv,
   },
   data() {
     return {
       project: {
         idprestation: '',
		nom: '',
		etat: '',
		prix: '',
		
       },
       isSaving:false,
     };
   },
   created() {
        // prends la valeur de l'id specifie dans l'url /api/:id
     const id = this.$route.params.id;
     
     axios.get(`Lalana/updateprestation.do/${id}`)
     .then(response => {
         let projectInfo = response.data
         this.project.idprestation = projectInfo.idprestation
		this.project.nom = projectInfo.nom
		this.project.etat = projectInfo.etat
		this.project.prix = projectInfo.prix
		
         return response
     })
     .catch(error => {
         Swal.fire({
             icon: 'error',
             title: 'An Error Occured!',
             showConfirmButton: false,
             timer: 1500
         })
         return error
     })
   },
   methods: {
     handleSave() {
             this.isSaving = true
         const id = this.$route.params.id;
         axios.patch(`Lalana/updateprestation.do/${id}`, this.project)
           .then(response => {
             Swal.fire({
                 icon: 'success',
                 title: 'Project updated successfully!',
                 showConfirmButton: false,
                 timer: 1500
             })
             this.isSaving = false
            this.project.idprestation = ""
		this.project.nom = ""
		this.project.etat = ""
		this.project.prix = ""
		
             return response
           })
           .catch(error => {
             this.isSaving = false
             Swal.fire({
                 icon: 'error',
                 title: 'An Error Occured!',
                 showConfirmButton: false,
                 timer: 1500
             })
             return error
           });
     },
   },
 };
 </script>
 