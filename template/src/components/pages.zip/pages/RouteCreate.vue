<template>
    <layout-div>
         <h2 class="text-center mt-5 mb-3">Edit Project</h2>
         <div class="card">
             <div class="card-header">
                 <router-link 
                     class="btn btn-outline-info float-right"
                     to="/">View All Projects
                 </router-link>
             </div>
             <div class="card-body">
                <form>
                    //#dataInput#
                    <div class="form-group">
    <label htmlFor="idroute">idroute</label>
    <input 
        v-model="project.idroute"
        type="String"
        class="form-control"
        id="idroute"
        name="idroute"/>
</div>
		<div class="form-group">
    <label htmlFor="nom">nom</label>
    <input 
        v-model="project.nom"
        type="String"
        class="form-control"
        id="nom"
        name="nom"/>
</div>
		
                     <button 
                         @click="handleSave()"
                         :disabled="isSaving"
                         type="button"
                         class="btn btn-outline-primary mt-3">
                         Save Project
                     </button>
                </form>
             </div>
         </div>
    </layout-div>
 </template>
 <script>

import  axios from 'axios';

import   LayoutDiv from '../LayoutDiv.vue';

import   Swal from 'sweetalert2';

 export default {
   name: 'RouteCreate',
   components: {
     LayoutDiv,
   },
   data() {
     return {
       project: {
         idroute: '',
		nom: '',
		
       },
       isSaving:false,
     };
   },
   created() {
            // prends la valeur de l'id specifie dans l'url /api/:id
     const id = this.$route.params.id;
     
     axios.get(`Lalana/updateroute.do/${id}`)
     .then(response => {
         let projectInfo = response.data
         this.project.idroute = projectInfo.idroute
		this.project.nom = projectInfo.nom
		
         return response
     })
     .catch(error => {
         Swal.fire({
             icon: 'error',
             title: 'An Error Occured!',
             showConfirmButton: false,
             timer: 1500
         })
         return error
     })
   },
   methods: {
     handleSave() {
               this.isSaving = true
         const id = this.$route.params.id;
         axios.patch(`Lalana/updateroute.do/${id}`, this.project)
           .then(response => {
             Swal.fire({
                 icon: 'success',
                 title: 'Project updated successfully!',
                 showConfirmButton: false,
                 timer: 1500
             })
             this.isSaving = false
            this.project.idroute = ""
		this.project.nom = ""
		
             return response
           })
           .catch(error => {
             this.isSaving = false
             Swal.fire({
                 icon: 'error',
                 title: 'An Error Occured!',
                 showConfirmButton: false,
                 timer: 1500
             })
             return error
           });
     },
   },
 };
 </script>